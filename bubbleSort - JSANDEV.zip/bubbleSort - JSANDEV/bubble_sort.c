// Bibliotecas utilizadas
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <locale.h> // Necessário para caracteres especiais

// Aqui definimos o tamanho do vetor
#define TAMANHO 10

/*
    Autor: JSANDEV
    Linkedin: https://www.linkedin.com/in/jsandev/
    Faça o download do código no Github: https://github.com/jsandev2030/
*/

/*
    MENU:
        1: Inserir vetor
        2: Inserir vetor aleatorio
        3: Ordenar vetor 
        4: Imprimir vetor
        5: Sobre
        6: Sair
*/

// Função para criar uma linha divisória entre os prints
int linha() {
    char x = ("%c", 6);
    for(int i = 0; i < 45; i++) {
        printf("%c", x);
    } printf("\n");
} 

// Função para criar vetor com valores inseridos pelo utilizador
int insere_vetor(int vetor[]) { 
    for(int elemento = 0; elemento <10; elemento++) {
        printf("Insira os valores do vetor posicao %d: \n", elemento);
        scanf("%d", &vetor[elemento]);
    }
    printf("\n");
    printf("Vetor inserido com sucesso.\n");
    linha();
    system("pause");
}

// Função para criar vetor com valores aleatorios
int insere_vetor_aleatorio(int vetor[]) {
    int elemento;

    // preenche o vetor com números entre 0 e 999
    for(elemento = 0; elemento < 10; elemento++){
        vetor[elemento] = rand() % 1000;
    }
    printf("Vetor inserido com sucesso.\n");
    linha();
    system("pause");
}

// Função que imprime o Vetor:
int imprime(int vetor[]) {
    printf("Vetor imprimido com sucesso.\n");
    for (int elemento = 0; elemento < 10; elemento++) {
        printf("%d ", vetor[elemento]); 
    }
    printf("\n");   
    linha();
    system("pause");
}  

// Função de ordenação do Bubble Sort
int ordena(int vetor[]) { 
   int elemento, aux, contador = 0;

   // Imprime vetor desordenado
   printf("Vetor desordenado: \n");
   for (elemento = 0; elemento < 10; elemento++) {
      printf("%d ", vetor[elemento]);
   }

   // Algoritmo de ordenação Bubblesort
    for (contador = 1; contador < 10; contador++) { 
      for (elemento = 0; elemento < 10 - 1; elemento++) { 
         if (vetor[elemento] > vetor[elemento + 1]) {
            aux = vetor[elemento];
            vetor[elemento] = vetor[elemento + 1];
            vetor[elemento + 1] = aux;
         }
      }
   }

    // Imprime vetor ordenado
    printf("\n\nVetor ordenado pelo Bubble Sort: \n");
    for (elemento = 0; elemento < 10; elemento++) {
        printf("%d ", vetor[elemento]);
    }
    printf("\n");
    linha();
    system("pause");
}

int sobre() { // Apresenta os dados do grupo que criou o projeto
    puts("Autor: JSANDEV");
    printf("Linkedin: https://www.linkedin.com/in/jsandev/");
    printf("\nGithub: https://github.com/jsandev2030/\n");

    linha();
    system("pause");
}

// Função que fecha a aplicação
int sair() { 
    printf("App encerrada com sucesso.");
    exit(EXIT_SUCCESS);
}

// Função principal que chama as outras funções consoante seleção do menu
int main(int argc, char const *argv[]) { 
    setlocale(LC_ALL, "Portuguese"); // Necessário para caracteres especiais

    int n1;
    int vetor[TAMANHO];

    do{
        printf("\n");
        linha();
        printf("Escolha a opera%c%co que deseja realizar: \n", 231, 227); // 231 para ç e 227 para ã
        linha();
        printf("1-Inserir vetor");
        printf("\n2-Inserir vetor aleatorio");
        printf("\n3-Ordenar vetor");
        printf("\n4-Imprimir vetor");
        printf("\n5-Sobre");
        printf("\n6-Sair\n");
        linha();
        scanf("\n%d", &n1);
        fflush (stdin);

        switch(n1) {
            case 1:
                linha();
                insere_vetor(vetor);
                linha();
            break;
            case 2:
                linha();
                insere_vetor_aleatorio(vetor);
                linha();
            break;
            case 3:
                linha();
                ordena(vetor);
                linha();
            break;
            case 4:
                linha();
                imprime(vetor);
                linha();
            break;
            case 5:
                linha();
                sobre();
                linha();
            break;
            case 6:
                linha();
                sair();
                linha();
            break;
            default:
                printf("\nInseriu um numero invalido, tente novamente..");
                return 0;
        }
    }while(n1 != 0);

   return 0;
}
