#include <stdio.h>
/*
    Autor: JSANDEV
    Linkedin: https://www.linkedin.com/in/jsandev/
    Faça o download do código no Github: https://github.com/jsandev2030/
*/

int conta_array_keys() {
    // Declara contador e calculo como inteiros vazios
    int contador, calculo;

    // Declara o numero de bytes que cada ponteiro representa
    int num_bytes = 4;

    // Declara um array com respectivos valores
    int vetor[] = {25, 50, 75, 100, 89, 57, 44, 65, 32, 55};
  
    // Define o tamanho das somas dos bytes do vetor
    contador = sizeof(vetor);

    // Calcula quantos elementos o array possui
    calculo = (contador/num_bytes);

    return calculo;
}

int main() {
    // Imprime o número de ponteiros/elementos/chaves/keys que o array possui
    printf("\nO array possui %d elementos.\n\n", conta_array_keys());

    return 0;
}
